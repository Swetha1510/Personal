$(function(){
	if(/chrom(e|ium)/.test(navigator.userAgent.toLowerCase())){
		$(".button").mousedown(function(){

			/*Removes previously created "ripple" divs*/
			$(".ripple").remove();

			/*Adds a new "ripple" div*/
			if ($(this).find(".ripple").length == 0) {
				$(this).append("<div class='ripple'></div>");
			}

			/*Setting Width and Height to "ripple" div. The text color of the button is also set as the background color of the "ripple" div*/
			var thsWd = $(this).outerWidth();
			var thsHt = $(this).outerHeight();
			var ripleDim = Math.max(thsWd,thsHt)/10;

			var ripplebg;
			if ($(this).attr("data-ripple-bg")!=undefined) {
				ripplebg = $(this).attr("data-ripple-bg");
			} else {
				ripplebg = $(this).css("color");
			}		

			$(this).find(".ripple").height(ripleDim).width(ripleDim).css("background-color",ripplebg);

			/*Setting the position of the "ripple" div. The "animateRipple" class is added to initiate the ripple animation*/
			$(this).find(".ripple").css({
				"top":event.pageY-$(this).offset().top,
				"left":event.pageX-$(this).offset().left,
			}).addClass("animateRipple");
			
		});		
	}
});